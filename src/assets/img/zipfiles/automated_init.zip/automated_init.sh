#!/bin/bash
#this command makes sure the script ends if ANY error occurs.
set -e

sitename=$1

#generating for database random password
genpwd (){ date +%s | sha256sum | base64 | head -c 32 ; echo;}
dbpasswd=$(genpwd)

echo "Credentials showing up when script is finished, write them down!"

echo "Generating VHOST config Files..."

mkdir -p "/var/www/html/bbsdesk/$sitename/public"
mkdir -p "/var/www/html/bbsdesk/$sitename/admin"
sudo chown -R wordpress /var/www/html/bbsdesk/$sitename
sudo cp /home/wordpress/scripts/init/bolboosch_bbhub_vhost.conf.example /etc/apache2/sites-available/$sitename.conf
cd /etc/apache2/sites-available
sudo sed -i -e "s/CHANGE_URL/$sitename/g" $sitename.conf
sudo ln -s /etc/apache2/sites-available/$sitename.conf /etc/apache2/sites-enabled/$sitename.conf
cd /var/www/html/bbsdesk/$sitename

echo "Installing Angular..."

git clone -b master git@gitlab.bolboosch.tech:bolboosch/bolboosch-hub-angular.git

cd bolboosch-hub-angular

#setup prod env
mv src/environments/environment.prod.ts.example src/environments/environment.prod.ts
sed -i -e "s/CHANGE_URL/$sitename/g" src/environments/environment.prod.ts

rm -rf dist/*
npm install
ng build
rm -rf ../public/*
mv dist/* ../public
rm -rf *

echo "Installing Laravel..."

cd ../admin

#pulling repo
git clone -b master git@gitlab.bolboosch.tech:bolboosch/new_kennisbank.git

#moving files 1 level down
mv new_kennisbank/* .

#removing folder
rm -rf new_kennisbank/

#creating required directories
mkdir -p vendor
mkdir -p bootstrap/cache
mkdir -p storage
mkdir -p storage/framework/sessions
mkdir -p storage/framework/views
mkdir -p storage/framework/cache
mkdir -p public

sudo chown -R $USER *
sudo chgrp -R www-data *

#change all directories to 755
find * -type d -print0 | xargs -0 chmod 0755

#change all files to 644
find . -type f -print0 | xargs -0 chmod 0644

#give user and webserver permission to read,write and execute
sudo chmod -R ug+rwx storage bootstrap/cache

mv config/app.php.example config/app.php

#change env, url for app.php
sed -i -e 's/CHANGE_ENV/remote/g' config/app.php
sed -i -e "s/CHANGE_URL/https:\/\$sitename\/admin/g" config/app.php
sed -i -e "s/CHANGE_ENDPOINT/https:\/\/api.bbsdesk.nl\/api\/v1\//g" config/app.php
sed -i -e "s/CHANGE_AUTH_INSTANCE_URL/https:\/\/$sitename\//g" config/app.php
sed -i -e "s/CHANGE_REMOTE_LOGIN_ACTIVE/true/g" config/app.php
sed -i -e "s/CHANGE_LOCAL_LOGOUT/false/g" config/app.php

#timezone fix
sed -i -e 's/UTC/Europe\/Amsterdam/g' config/app.php

#create DB, user = sitename and password = dbpasswd
cp /home/wordpress/scripts/init/bb_hub_create_instance_db.sql $sitename.sql
cp /home/wordpress/scripts/init/bb_hub_procedures_functions.sql procedure.sql

sed -i -e "s/CHANGE_DB_NAME/$sitename/g" $sitename.sql
sed -i -e "s/CHANGE_PASSWD/$dbpasswd/g" $sitename.sql

mysql -u maintenance -pagrbnDVNo62J0t0D < $sitename.sql

rm $sitename.sql

mv config/database.php.example config/database.php

#change env, url for database.php
sed -i -e "s/CHANGE_DATABASE/bb_hub_data_$sitename/g" config/database.php
sed -i -e "s/CHANGE_USER_DATABASE/$sitename/g" config/database.php
sed -i -e "s/CHANGE_PASSWORD_DATABASE/$dbpasswd/g" config/database.php

#Installing dependencies
npm install
composer install
php artisan cache:clear
composer dumpautoload
npm run prod
php artisan migrate --seed

#Creating new job based on example job. Due to a bug in Jenkins I had to disable the copied job and re-enable it.

curl -X POST -u cas:21af4817ae552fd4ce8fb1abf3bba672 "http://35.156.211.176:9090/createItem?name=$sitename&mode=copy&from=example.bbsdesk.nl" #create job for master
curl -X POST -u cas:21af4817ae552fd4ce8fb1abf3bba672 "http://35.156.211.176:9090/job/$sitename/disable" #disable master job
curl -X POST -u cas:21af4817ae552fd4ce8fb1abf3bba672 "http://35.156.211.176:9090/job/$sitename/enable" #enable master job

cd /home/wordpress/scripts/transip

dnsSub=$(echo $sitename | sed 's/[.][^-]*//')

php addDNS.php $dnsSub

# reload webserver to apply changes
sudo service apache2 reload



echo "\nSite is now running at: $sitename \n"
echo "Database info:"
echo "  database: bb_hub_data_$sitename"
echo "  database user: $sitename"
echo "  database password: $dbpasswd"

echo "\nDon't forget to add a subdomain in the DNS for $sitename at your provider!"